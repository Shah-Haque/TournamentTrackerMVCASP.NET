﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TournamentTrackerMVCUI.Models
{
    public class RoundMVCModel
    {
        /// <summary>
        /// Number of rounds
        /// </summary>
        public int RoundNumber { get; set; }

        /// <summary>
        /// Name of Round
        /// </summary>
        public string RoundName { get; set; }

        /// <summary>
        /// Status of round
        /// </summary>
        public RoundStatus Status { get; set; }
    }
}