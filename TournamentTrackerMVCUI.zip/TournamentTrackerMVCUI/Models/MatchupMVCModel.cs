﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TournamentTrackerMVCUI.Models
{
    public class MatchupMVCModel
    {
        //matchup ID
        //Matchup Entry ID - Team Name- score (2x)
        /// <summary>
        /// Id of matchups
        /// </summary>
        public int MatchupID { get; set; }
        /// <summary>
        /// ID of Tournament
        /// </summary>
        public int TournamentID{ get; set; }
        /// <summary>
        /// Number of Round within Tournament
        /// </summary>
        public int RoundNumber { get; set; }
        /// <summary>
        /// ID of the the first Matchups between teams
        /// </summary>
        public int FirstTeamMatchupEntryID { get; set; }
        /// <summary>
        /// Name of the First Team
        /// </summary>
        public string FirstTeamName { get; set; }
        /// <summary>
        /// Score of the first team
        /// </summary>
        public double FirstTeamScore { get; set; }
        /// <summary>
        /// ID of the second competing team 
        /// </summary>
        public int SecondTeamMatchupEntryID { get; set; }
        /// <summary>
        /// Name of the second team
        /// </summary>
        public string SecondTeamName { get; set; }
        /// <summary>
        /// Score of Second team
        /// </summary>
        public double SecondTeamScore { get; set; }
    }
}