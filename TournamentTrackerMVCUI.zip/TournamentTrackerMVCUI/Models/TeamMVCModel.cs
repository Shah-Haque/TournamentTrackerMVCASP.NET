﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TrackerLibrary.Models;

namespace TournamentTrackerMVCUI.Models
{
    public class TeamMVCModel
    {
        /// <summary>
        /// Creates a name for your team
        /// </summary>
        [Display(Name = "Team Name")]
        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string TeamName { get; set; }

        /// <summary>
        /// List of teammembers
        /// </summary>
        [Display(Name = "List of Team Members")]
        public List<SelectListItem> TeamMembers { get; set; } = new List<SelectListItem>();

        /// <summary>
        /// Select your Team Members for your Team
        /// </summary>
        [Display(Name = "Select your Team Members")]
        public List<string> SelectedTeamMembers { get; set; }= new List<string>(); 
    }
}