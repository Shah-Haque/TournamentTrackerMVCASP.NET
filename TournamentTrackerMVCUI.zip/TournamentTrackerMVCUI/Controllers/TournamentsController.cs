﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TrackerLibrary;
using TrackerLibrary.Models;
using TournamentTrackerMVCUI.Models;
using System.Web.Mvc;

namespace TournamentTrackerMVCUI.Controllers
{
    public class TournamentsController : Controller
    {
        // GET: Tournaments
        public ActionResult Index()
        {
            return RedirectToAction("Index","Home");
        }


     
        [HttpPost]
        [ValidateAntiForgeryToken()]
        public ActionResult EditTournamentMatchup(MatchupMVCModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<TournamentModel> tournaments = GlobalConfig.Connection.GetTournament_All();
                    TournamentModel t = tournaments.Where(x => x.TournamentID == model.TournamentID).First();
                    MatchupModel Foundmatchup = new MatchupModel();


                    foreach (var Round in t.Rounds)
                    {
                        foreach (var Matchup in Round)
                        {
                            if (Matchup.MatchupID == model.MatchupID)
                            {
                                Foundmatchup = Matchup;
                            }
                        }
                    }

                    for (int i = 0; i < Foundmatchup.Entries.Count; i++)
                    {
                        if (i == 0)
                        {
                            Foundmatchup.Entries[i].Score = model.FirstTeamScore;

                        }
                        else if (i == 1)
                        {
                            Foundmatchup.Entries[i].Score = model.SecondTeamScore;
                        }
                    }
                    TournamentLogic.UpdateTournamentResults(t);

                }
            }
            catch 
            {
            }
            return RedirectToAction("Details", "Tournaments", new { id = model.TournamentID, RoundID = model.RoundNumber });
        }

        /// <summary>
        /// This shows the Tournament Matchup Details 
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="roundID"></param>
        /// <returns></returns>
        public ActionResult Details(int ID, int roundID = 0)
        {
            List<TournamentModel> tournaments = GlobalConfig.Connection.GetTournament_All();

            try
            {
                // information going into the view
                TournamentMVCViewDetailsModel input = new TournamentMVCViewDetailsModel();
                TournamentModel t = tournaments.Where(x => x.TournamentID == ID).First();

                input.TournamentName = t.TournamentName;

                var orderedRounds = t.Rounds.OrderBy(x => x.First().MatchupRound).ToList();
                bool activeFound = false;

                for (int i = 0; i < orderedRounds.Count; i++)
                {
                    RoundStatus status = RoundStatus.Locked;

                    if (!activeFound)
                    {
                        if (orderedRounds[i].TrueForAll(x => x.Winner != null))
                        {
                            status = RoundStatus.Complete;
                        }
                        else
                        {
                            status = RoundStatus.Active;
                            activeFound = true;
                            if (roundID == 0)
                            {
                                roundID = i + 1;
                            }
                        }
                    }

                    input.Rounds.Add(new RoundMVCModel { RoundName = "Round " + (i + 1), Status = status, RoundNumber = i + 1 });
                }
              
                input.Matchups = getMatchups(orderedRounds[roundID - 1], ID, roundID);

                return View(input);
            }

            catch 
            {
                return RedirectToAction("Index","Home");
            } 
        }

        /// <summary>
        /// This will get the matchups from the tournaments
        /// </summary>
        /// <param name="input"></param>
        /// <param name="TournamentD"></param>
        /// <param name="roundID"></param>
        /// <returns></returns>
        private List<MatchupMVCModel> getMatchups (List<MatchupModel> input, int TournamentD, int roundID = 0)
        {
            List<MatchupMVCModel> output = new List<MatchupMVCModel>();

            foreach (var item in input)
            {
                int TeamTwoID = 0;
                string teamoneName = "";
                string TeamTwoName = "Bye";
                double TeamTwoScore = 0;

                if (item.Entries[0].TeamCompeting == null)
                {
                    teamoneName = "To be determined..";
                }
                else
                {
                    teamoneName = item.Entries[0].TeamCompeting.TeamName;
                }
                if (item.Entries.Count > 1 )
                {
                    TeamTwoID = item.Entries[1].MatchupEntryID;

                    if (item.Entries[1].TeamCompeting == null)
                    {
                        TeamTwoName = "To be determined..";
                    }
                    else
                    {
                        TeamTwoName = item.Entries[1].TeamCompeting.TeamName;
                    }
                    TeamTwoScore = item.Entries[1].Score;
                }

                output.Add(new MatchupMVCModel
                {
                    MatchupID = item.MatchupID,
                    TournamentID = TournamentD,
                    RoundNumber = roundID,
                    FirstTeamMatchupEntryID = item.Entries[0].MatchupEntryID,
                    FirstTeamName = teamoneName,
                    FirstTeamScore = item.Entries[0].Score,
                    SecondTeamMatchupEntryID = TeamTwoID,
                    SecondTeamName = TeamTwoName,
                    SecondTeamScore = TeamTwoScore,
                }); 
               
            }

            return output;
        }

        public ActionResult Create()
        {
            TournamentMVCCreateModel input = new TournamentMVCCreateModel();
            List<TeamModel> AllTeams = GlobalConfig.Connection.GetTeam_All();
            List<PrizeModel> allPrizes = GlobalConfig.Connection.GetPrizes_All();

            input.EnteredTeams = AllTeams.Select 
                (x => new SelectListItem { Text = x.TeamName, Value = x.TeamID.ToString() }).ToList();
            input.Prizes = allPrizes.Select
                (x => new SelectListItem { Text = x.PlaceName, Value = x.PrizesID.ToString() }).ToList();

            return View(input);
        }

        // POST: People/Create
        [ValidateAntiForgeryToken()]
        [HttpPost]
        public ActionResult Create(TournamentMVCCreateModel model)
        {
            try
            {
               // Checks whether the model state is valid  
               // and the selected entered teams is greater than 0
               if (ModelState.IsValid && model.SelectedEnteredTeams.Count > 0)
               {
                    List<PrizeModel> allPrizes = GlobalConfig.Connection.GetPrizes_All();
                    List<TeamModel> AllTeams = GlobalConfig.Connection.GetTeam_All();


                    //Checks the values for the Tournament Model
                    TournamentModel t = new TournamentModel();
                    t.TournamentName = model.TournamentName;
                    t.EntryFee = model.EntryFee;
                    t.EnteredTeams = model.SelectedEnteredTeams.Select
                        (x => AllTeams.Where(y => y.TeamID == int.Parse(x)).First()).ToList();
                    t.Prizes = model.SelectedPrizes.Select
                        (x => allPrizes.Where(y => y.PrizesID == int.Parse(x)).First()).ToList();

                   

                    //Wire our matchups in the tournament viewer
                    TournamentLogic.CreateRounds(t);

                    // Creates a connection for the newly created tournament
                    GlobalConfig.Connection.createTournament(t);

                    // alerts users to a new round
                    t.AlertUsersToNewRound();

                    // redirects the user to the home page
                    return RedirectToAction("Index", "Home");
               }
               else
               {
                    // if creating a tournament fails it will redirect 
                    // to the same create Tournament page
                    return RedirectToAction("Create");
               }
            }
            catch (Exception ex)
            {
                return View(ex);
            }
        }
    }
}