﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TournamentTrackerMVCUI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            // this gets all available tournaments
            List<TournamentModel> tournaments = GlobalConfig.Connection.GetTournament_All();

            return View(tournaments);
        }

    }
}