﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TrackerLibrary;
using TrackerLibrary.Models;

namespace TournamentTrackerMVCUI.Controllers
{
    public class PrizesController : Controller
    {
        // GET: Prizes
        public ActionResult Index()
        {
            // List of people that will be passed to the view
            List<PrizeModel> allPrizes = GlobalConfig.Connection.GetPrizes_All();

            // This will return the people to he view
            return View(allPrizes);
        }

        // GET: Prizes/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Prizes/Create
        [ValidateAntiForgeryToken()]
        [HttpPost]
        public ActionResult Create(PrizeModel p)
        {
            return NewMethod(p);
        }

        private ActionResult NewMethod(PrizeModel p)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GlobalConfig.Connection.CreatePrize(p);

                    return RedirectToAction("Index");
                }
                else
                    return ReturnPrize();
            }
            catch
            {
                return View();
            }
        }

        private ActionResult ReturnPrize()
        {
            return View();
        }
    }
}